@file:JvmName("KrobotFunctions")

/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.util

import fr.litarvan.krobot.Krobot
import fr.litarvan.krobot.motor.User
import fr.litarvan.krobot.bot.Bot
import fr.litarvan.krobot.exception.CrashReporter
import fr.litarvan.krobot.motor.IMotor
import org.apache.logging.log4j.Logger
import java.io.File

/**
 * @since 1.2.0
 * @return The current Krobot instance
 */
fun krobot(): Krobot
{
    return Krobot.instance
}

/**
 * @since 1.2.0
 * @return The current crash reporter
 */
fun reporter(): CrashReporter
{
    return krobot().crashReporter
}

/**
 * Mention the given user (example: @User)
 *
 * @since 1.1.0
 * @return The mention as a [String]
 */
fun mention(user: User): String
{
    if (krobot().startedMotor != null)
    {
        return krobot().startedMotor!!.mention(user)
    }

    throw RuntimeException("Can't use the mention() function when a bot isn't started")
}

/**
 * @since 1.1.0
 * @return If a bot is launched
 */
fun isBotStarted(): Boolean
{
    return krobot().startedMotor != null
}

/**
 * @throws NullPointerException If there is no started bot
 *
 * @since 1.1.0
 * @return The current started bot
 */
fun bot(): Bot
{
    return motor().current!!
}

/**
 * @throws RuntimeException If no bot is started
 *
 * @since 1.1.0
 * @return The current started motor
 */
fun motor(): IMotor
{
    if (!isBotStarted())
    {
        throw RuntimeException("No bot started")
    }

    return krobot().startedMotor!!
}

/**
 * @since 1.1.0
 * @return The current Krobot logger
 */
fun logger(): Logger
{
    return Krobot.LOGGER
}

/**
 * @since 1.1.0
 * @return The current bot message prefix (example: [My Bot])
 */
fun prefix(): String
{
    return "[${bot().name}]"
}

/**
 * @throws NullPointerException If there is no started bot
 *
 * @since 1.1.0
 * @return A file with the given name from the current bot folder
 */
fun file(name: String): File
{
    return File(bot().identifier, name)
}