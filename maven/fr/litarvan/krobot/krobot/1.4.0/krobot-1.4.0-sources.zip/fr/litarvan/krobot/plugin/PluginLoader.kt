/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.plugin

import java.io.BufferedReader
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader
import java.lang.reflect.Method
import java.net.URL
import java.net.URLClassLoader
import java.util.ArrayList
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

import fr.litarvan.krobot.util.logger

/**
 * The Plugin Loader
 *
 *
 * The Plugin Loader is an object that can load jars from
 * a given directory, read a file where the main class
 * name is and then instantiate their main class
 *
 * @param folder The folder where are the jars
 *
 * @author Litarvan
 * @version 1.0.0
 */
abstract class PluginLoader<T>(val folder: File)
{
    /**
     * The plugin list
     */
    val plugins = ArrayList<T>()

    /**
     * Load all the plugins
     */
    fun start()
    {
        // Getting the files in the plugin folder
        val plugins = folder.listFiles()

        if (plugins == null || plugins.size == 0)
        {
            logger().info("Nothing to load.")
            folder.mkdir()

            return
        }

        val addURL: Method
        val classLoader = ClassLoader.getSystemClassLoader() as URLClassLoader

        try
        {
            addURL = URLClassLoader::class.java.getDeclaredMethod("addURL", URL::class.java)
            addURL.isAccessible = true
        }
        catch (e: Exception)
        {
            logger().error("Error ! Can't get the class loader addURL method !", e)
            return
        }

        for (file in plugins)
        {
            if (!file.name.endsWith(".jar"))
            {
                logger().info("Found a non-plugin file : " + file.name)
                continue
            }

            val zip: ZipFile
            var reader: BufferedReader? = null
            var `in`: InputStream? = null
            val mainClass: String?

            try
            {
                zip = ZipFile(file)
                val entries = zip.entries()
                var entry: ZipEntry

                while (entries.hasMoreElements())
                {
                    entry = entries.nextElement()
                    if (entry.name == "main-class.krobot")
                    {
                        `in` = zip.getInputStream(entry)
                        break
                    }
                }

                if (`in` == null)
                {
                    logger().error("Error : Can't find main-class.krobot in plugin : " + file.name)
                    continue
                }

                reader = BufferedReader(InputStreamReader(`in`))
                mainClass = reader.readLine()
                if (mainClass == null)
                {
                    logger().error("Error : Empty main-class.krobot in plugin : " + file.name)
                    continue
                }
            }
            catch (e: Exception)
            {
                logger().error("Exception while loading the plugin : " + file.name, e)
                break
            }
            finally
            {
                if (`in` != null)
                    try
                    {
                        `in`.close()
                    }
                    catch (e: IOException)
                    {
                        logger().error("Warning, can't close the main-class file input stream", e)
                    }

                if (reader != null)
                    try
                    {
                        reader.close()
                    }
                    catch (e: IOException)
                    {
                        logger().error("Warning ,can't close the main-class file buffered reader", e)
                    }

            }

            // Adding it to the classpath
            try
            {
                addURL.invoke(classLoader, file.toURI().toURL())
            }
            catch (e: Exception)
            {
                logger().error("Can't add the plugin " + file.name + " to the classpath")
                break
            }

            // Calling the main class
            val pluginClass: Class<*>
            val plugin: T
            try
            {
                pluginClass = Class.forName(mainClass)
                plugin = pluginClass.newInstance() as T
            }
            catch (e: ClassNotFoundException)
            {
                logger().error("Can't find the main class of the plugin " + file.name, e)
                break
            }
            catch (e: InstantiationException)
            {
                logger().error("Can't initialize the empty constructor of the plugin " + file.name, e)
                break
            }
            catch (e: IllegalAccessException)
            {
                logger().error("Can't initialize the empty constructor of the plugin " + file.name, e)
                break
            }

            // Loading the plugin
            this.load(plugin)

            this.plugins.add(plugin)
        }

        logger().info("Done")
    }

    /**
     * Load a plugin
     *
     * @param plugin The plugin to load
     */
     abstract fun load(plugin: T)
}