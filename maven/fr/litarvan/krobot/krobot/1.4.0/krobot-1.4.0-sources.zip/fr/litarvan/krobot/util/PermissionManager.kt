/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.util

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import fr.litarvan.krobot.motor.Conversation
import fr.litarvan.krobot.motor.User
import java.io.Closeable
import java.io.File
import java.util.*
import java.lang.reflect.Type

/**
 * The Permission Manager
 *
 *
 * A permission manager can manage permissions for users
 * and manage admins.
 *
 * @author Litarvan
 * @version 1.4.0
 * @since 1.3.0
 */
class PermissionManager
{
    /**
     * The list of the user permissions
     */
    private var permissions = HashMap<String, ArrayList<String>>()

    /**
     * The JSON object used in the [save] and [load] methods
     */
    private val gson = Gson()

    /**
     * The [Type] of the [permissions] map
     */
    private val mapType = object : TypeToken<HashMap<String, ArrayList<String>>>()
    {
    }.type

    /**
     * Add permission(s) to a given user
     *
     * @param user The user to add permissions
     * @param perms The permissions to add to the user
     */
    fun addPermission(user: User, vararg perms: String)
    {
        perms.forEach {
            if (!permissions.containsKey(user.id))
            {
                permissions[user.id] = ArrayList<String>()
            }

            permissions[user.id]!!.add(it)
        }
    }

    /**
     * Remove permission(s) to a given user
     *
     * @param user The user to remove permissions
     * @param perms The permissions to remove to the user
     */
    fun removePermission(user: User, vararg perms: String)
    {
        perms.forEach {
            if (!permissions.containsKey(user.id))
            {
                return
            }

            permissions[user.id]!!.remove(it);
        }
    }

    /**
     * Check if the user has a permission
     *
     * @param user The user to check
     * @param perm The permission to check
     *
     * @return If he has the permission
     */
    fun hasPermission(user: User, perm: String): Boolean
    {
        return permissions.containsKey(user.id) && permissions[user.id]!!.contains(perm)
    }

    /**
     * Check if the user has a permission and if he hasn't,
     * sending to him a missing permission message
     *
     * @param user The user to check
     * @param perm The permission to check
     * @param conversation The conversation where to send the error message
     * @param message The message to send ({} will be replaced by the permission)
     *
     * @return If he has the permission
     */
    fun hasOrFail(user: User, perm: String, conversation: Conversation, message: String): Boolean
    {
        val has = hasPermission(user, perm)

        if (!has)
        {
            conversation.sendMessage("${mention(user)} ${message.format(perm)}")
        }

        return has
    }

    /**
     * Save the permissions to a JSON file
     *
     * @param file The file where to save the permissions
     */
    fun save(file: File)
    {
        file.parentFile.mkdirs()
        var writer: Closeable? = null

        try
        {
            writer = file.writer()
            gson.toJson(permissions, mapType, writer)
        }
        finally
        {
            try
            {
                if (writer != null)
                {
                    writer.close()
                }
            }
            catch (e: Throwable)
            {
            }
        }
    }

    /**
     * Load the permissions from a JSON file
     *
     * @param file The file where to load the permissions
     */
    fun load(file: File)
    {
        var reader: Closeable? = null

        try
        {
            reader = file.reader()
            permissions = gson.fromJson(reader, mapType)
        }
        finally
        {
            try
            {
                if (reader != null)
                {
                    reader.close()
                }
            }
            catch (e: Throwable)
            {
            }
        }
    }
}