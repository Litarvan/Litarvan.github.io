/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.motor

import java.io.File

/**
 * A User
 *
 *
 * This class is overridden by the motors to add
 * some informations. It represents a simple User,
 * with an username.
 *
 * @author Litarvan
 * @version 1.4.0
 * @since 1.0.0
 */
abstract class User : IdObject()
{
    /**
     * The user username
     */
    abstract val username : String

    /**
     * The user PM conversation
     */
    abstract val privateConversation: Conversation
}

/**
 * A Message
 *
 *
 * This class is overridden by the motors to add
 * some informations. It represents a simple Message,
 * with an content and a author ([User]).
 *
 * @see User
 *
 * @author Litarvan
 * @version 1.3.0
 * @since 1.0.0
 */
abstract class Message : IdObject()
{
    /**
     * The message content text
     */
    abstract val text : String

    /**
     * The message author
     */
    abstract val author : User
}

/**
 * A Conversation
 *
 *
 * This class is overridden by the motors to add
 * some informations. It represents a simple Conversation,
 * with a name, a boolean defining if it is a private
 * conversation, and methods to send message or files.
 *
 * @author Litarvan
 * @version 1.3.4
 * @since 1.0.0
 */
abstract class Conversation : IdObject()
{
    /**
     * The name of the converstaion
     */
    abstract val name : String

    /**
     * If the conversation is private
     */
    abstract val private : Boolean

    /**
     * Send a message on this conversation
     *
     * @param content The content of the message to send
     */
    abstract fun sendMessage(content: String)

    /**
     * Send a file on this conversation (not always supported)
     *
     * @param file The file to send
     */
    abstract fun sendFile(file: File)

    /**
     * Find a user by its ID
     *
     * @param id The ID of the user to find
     *
     * @return The found user or null if not found
     */
    abstract fun userById(id: String): User?

    /**
     * Find a user by its name
     *
     * @param name The name of the user to find
     *
     * @return The found user or null if not found
     */
    abstract fun userByName(name: String): User?

    /**
     * @return The list of the users of this conversation
     */
    abstract fun members(): Array<User>
}

/**
 * The ID Object
 *
 *
 * An ID Object is an object that has an unique ID
 *
 * @author Litarvan
 * @version 1.3.0
 * @since 1.3.0
 */
abstract class IdObject
{
    /**
     * The object ID
     */
    abstract val id: String
}