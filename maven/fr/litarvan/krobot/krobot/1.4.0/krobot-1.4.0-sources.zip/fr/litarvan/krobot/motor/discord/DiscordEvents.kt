/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.motor.discord

import fr.litarvan.krobot.bot.StartEvent
import fr.litarvan.krobot.bot.StopEvent
import fr.litarvan.krobot.motor.IMotor
import net.dv8tion.jda.core.events.ReadyEvent

/**
 * The Discord Start Event
 *
 *
 * A [StartEvent] but with the JDA API [ReadyEvent]
 *
 * @see [StartEvent]
 * @see [ReadyEvent]
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.0.0
 */
class DiscordStartEvent(motor: IMotor, event: ReadyEvent) : StartEvent(motor)

/**
 * The Discord Stop Event
 *
 *
 * A [StopEvent] but with the JDA API [ShutdownEvent]
 *
 * @see [StopEvent]
 * @see [ShutdownEvent]
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.0.0
 */
class DiscordStopEvent(motor: IMotor) : StopEvent(motor)