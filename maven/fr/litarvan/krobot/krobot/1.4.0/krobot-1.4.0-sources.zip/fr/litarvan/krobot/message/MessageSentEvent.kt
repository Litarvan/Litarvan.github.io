/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.message

import fr.litarvan.krobot.message.CancellableEvent
import fr.litarvan.krobot.motor.Conversation
import fr.litarvan.krobot.motor.Message
import fr.litarvan.krobot.motor.IMotor

/**
 * The Message Sent Event
 *
 *
 * This message is used by the [IMessageListener] and called by the
 * [IMotor] when a message was sent from a conversation.
 *
 * @param message The sent message
 * @param conversation The conversation where the message was sent
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.0.0
 */
open class MessageSentEvent(val message: Message, val conversation: Conversation) : CancellableEvent()