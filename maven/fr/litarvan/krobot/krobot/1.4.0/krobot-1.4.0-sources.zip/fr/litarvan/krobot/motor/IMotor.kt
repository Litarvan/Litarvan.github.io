/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.motor

import fr.litarvan.krobot.bot.Bot
import java.util.*
import fr.litarvan.krobot.util.*

/**
 * The Motor
 *
 *
 * A Motor is an implementation of a chat software (like
 * Skype or Discord) API.
 *
 * The Motor also manage a bot launching and implements
 * some util functions like a mention function
 *
 * Any motor can be used by any [Bot]
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.0.0
 */
interface IMotor
{
    /**
     * The motor full name
     */
    val name: String

    /**
     * The motor identifier (simple, lower case, no spaces or
     * special chars)
     */
    val identifier: String

    /**
     * The motor version
     */
    val version: String

    /**
     * The current bot that the motor is using
     */
    val current: Bot?

    /**
     * Called when the motor is loaded from the jar
     */
    fun init() {}

    /**
     * Start the given bot using this motor
     */
    fun startBot(bot: Bot)

    /**
     * Shutdown the current bot
     */
    fun shutdownCurrent()

    /**
     * Mention a user
     *
     * @param user The user to mention
     */
    fun mention(user: User): String
    {
        return "@${user.username}"
    }

    /**
     * Return an HashMap containing the Markdown keys :
     *
     * - [EMPHASIS]
     * - [BOLD]
     * - [STRIKE]
     * - [CODE]
     * - [UNDERLINE]
     *
     * With their value character. Example, if to do bold
     * word you need to do "hey i am **bold**" you need to
     * provide [BOLD] => "**"
     *
     * If it isn't possible you can provide not all the keys
     * or just return null if markdown isn't supported
     *
     * For the [CODE] code, {LANG}, if provided, will be replaced
     * by the used language (example: Java)
     *
     * @return An HashMap containing the markdown keys with their
     * value (null if markdown isn't supported by this motor)
     */
    fun markdownTable(): HashMap<String, String>?
    {
        return null
    }
}