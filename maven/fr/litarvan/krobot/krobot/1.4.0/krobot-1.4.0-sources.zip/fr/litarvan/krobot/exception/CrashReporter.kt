/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.exception

import java.io.File
import java.io.FileWriter
import java.io.IOException
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date

import fr.litarvan.krobot.Krobot
import fr.litarvan.krobot.util.logger

/**
 * The Crash Reporter
 *
 *
 * The Crash Reporter can catches errors and save them
 * as a crash report to a given folder.
 *
 * @param dir The directory where to save the crashes
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.0.0
 */
class CrashReporter(private val dir: File)
{
    /**
     * Catch an error and write it to a crash
     *
     * @param e       The error to catch
     * @param message The error message
     */
    fun catchError(e: Exception, message: String)
    {
        logger().error("Exception caught ! " + message)
        println(e.makeCrashReport())

        try
        {
            writeError(e)
        }
        catch (e2: IOException)
        {
            logger().error("Unable to write the crash report !")
            e.printStackTrace()
        }

        System.exit(1)
    }

    /**
     * Write a stack-trace to a file
     *
     * @param e The exception
     * @throws IOException If it failed to write the crash
     */
    @Throws(IOException::class)
    fun writeError(e: Exception)
    {
        var number = 0
        var file: File = File(dir, "crash-$number.txt")
        while (file.exists())
        {
            file = File(dir, "crash-$number.txt")
            number++
        }

        logger().error("Writing crash report to : " + file.absolutePath)
        file.parentFile.mkdirs()

        val fw = FileWriter(file)
        fw.write(e.makeCrashReport())
        fw.close()

        logger().error("Done")
    }

    companion object
    {
        /**
         * Create a crash report from an exception
         *
         * @return The made crash report
         */
        fun Exception.makeCrashReport(): String
        {
            val dateFormat = SimpleDateFormat("yyyy/MM/dd HH:mm:ss")
            val date = Date()

            var report = "# Krobot Crash Report\n" + "#\n" + "# At : " + dateFormat.format(date) + "\n" + "#\n" + "# Exception : " + this.javaClass.simpleName + "\n"

            report += "\n# " + this.toString()

            val stackTrace = this.stackTrace
            for (element in stackTrace)
                report += "\n#     " + element

            return report
        }
    }
}