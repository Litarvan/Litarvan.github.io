/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.command

import fr.litarvan.krobot.exception.CommandException
import java.util.*
import java.util.regex.Pattern

/**
 * The CommandHandler
 *
 *
 * This object can manage a list of [Command], to implement it,
 * you'll need to call the [handle] method with the input
 * (Example: '/command arg1 arg2').
 *
 * This method will search for the command (if it can't find it he will
 * call the [handleUnknownCommand]), check its syntax (if invalid will
 * call [handleBadSyntax]) and then call all the [ICommandListener].
 *
 * If the message wasn't cancelled, the command will be called.
 *
 * It contains a list of [Command] and a list of [ICommandListener],
 * you can use the [register] and the [registerListener] methods to
 * add things to these lists.
 *
 * @see Command
 * @see ICommandListener
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.1.0
 */
abstract class CommandHandler
{
    /**
     * The list of command
     */
    val commandList = ArrayList<Command>()

    /**
     * The list of command listener
     */
    val listenerList = ArrayList<ICommandListener>()

    abstract fun handleBadSyntax(caller: ICommandCaller, command: Command, args: List<String>)
    abstract fun handleUnknownCommand(caller: ICommandCaller, command: String, args: List<String>)

    /**
     * Handle a line (example: /command arg1 arg2 "arg 3")
     *
     * It will call the corresponding command or call the handleUnknownCommand method.
     * Then it will check its syntax and can call the handleBadSyntax method.
     * Finally it will call all the CommandListener and launch the command if it
     * wasn't cancelled by a listener.
     *
     * @param line The typed line
     * @param caller Object representing who/what called the command
     *
     * @throws CommandException If the command threw one
    */
    @Throws(CommandException::class)
    protected fun handle(line: String, caller: ICommandCaller)
    {
        val line = fullSplit(line.trim { it <= ' ' })

        if (line.size == 0)
        {
            return
        }

        val command = line[0]
        val args =
                if (line.size == 1)
                {
                    ArrayList<String>()
                }
                else
                {
                    line.subList(1, line.size)
                }

        var c: Command? = null
        for (com in commandList)
        {
            if (com.command == command)
            {
                c = com
                break
            }
        }

        // If no command was found
        if (c == null)
        {
            handleUnknownCommand(caller, command, args)
            return
        }

        // Checking its syntax
        if (!c.checkSyntax(args))
        {
            handleBadSyntax(caller, c, args)
            return
        }

        val event = CommandCalledEvent(c, args)

        // Calling the listeners
        for (listener in listenerList)
        {
            listener.handleCommand(event)
        }

        if (!event.cancelled)
        {
            // Calling it
            c.handleCall(caller, args)
        }
    }

    private fun fullSplit(line: String): List<String>
    {
        // Splitting the command by space, excepted the one surrounded by double-quotes
        // Thanks to Jan Goyvaerts from Stack Overflow
        val matchList = ArrayList<String>()
        val regex = Pattern.compile("[^\\s\"']+|\"([^\"]*)\"|'([^']*)'")
        val regexMatcher = regex.matcher(line)

        while (regexMatcher.find())
        {
            if (regexMatcher.group(1) != null)
            {
                matchList.add(regexMatcher.group(1))
            }
            else if (regexMatcher.group(2) != null)
            {
                matchList.add(regexMatcher.group(2))
            }
            else
            {
                matchList.add(regexMatcher.group())
            }
        }

        return matchList
    }

    /**
     * Register commands
     *
     * @param commands The commands to register
     */
    fun register(vararg commands: Command)
    {
        commandList.addAll(commands)
    }

    /**
     * Register a command listener
     *
     * @param listener The listener to register
     */
    fun registerListener(listener: ICommandListener)
    {
        listenerList.add(listener)
    }
}