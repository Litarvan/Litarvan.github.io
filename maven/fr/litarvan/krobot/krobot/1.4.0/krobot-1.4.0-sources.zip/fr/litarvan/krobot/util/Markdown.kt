@file:JvmName("Markdown")

/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.util

import java.util.*

/**
 * A Regex to find all the arguments in a string.
 *
 * Example : Lorem ipsum {ARG1} lorem {ARG2} ipsum
 * {ARG1} and {ARG2} will be found
 */
@JvmField val ARGS_REGEX = "\\$\\{[\\w]+\\}".toRegex()

/**
 * A code corresponding to the emphasis modifier
 * (Default: _ Example: _hey_)
 *
 * The modifier codes are used as key in the markdown tables
 */
const val EMPHASIS = "em"

/**
 * A code corresponding to the bold modifier
 * (Default: ** Example: **hey**)
 *
 * The modifier codes are used as key in the markdown tables
 */
const val BOLD = "b"

/**
 * A code corresponding to the code modifier
 * (Default: ```{LANG} Example: ```kotlin println("hey")```
 *
 * The modifier codes are used as key in the markdown tables
 */
const val CODE = "code"

/**
 * A code corresponding to the underline modifier
 * (Default: __ Example: __hey__)
 *
 * The modifier codes are used as key in the markdown tables
 */
const val UNDERLINE = "ul"

/**
 * A code corresponding to the strike modifier
 * (Default: ~~ Example: ~~hey~~)
 *
 * The modifier codes are used as key in the markdown tables
 */
const val STRIKE = "s"

/**
 * The classic markdown table containing :
 *
 * [EMPHASIS] => _
 * [BOLD] => **
 * [UNDERLINE] => __
 * [STRIKE] => ~~
 * [CODE] => ```
 */
private val classicMarkdown = HashMap<String, String>()

/**
 * Apply emphasis on this string using markdown
 *
 * @since 1.2.0
 * @return This string with emphasis with markdown
 */
fun String.mdEmphasis(): String
{
    return this.md(EMPHASIS)
}

/**
 * Set this string bold using markdown
 *
 * @since 1.2.0
 * @return This string as bold with markdown
 */
fun String.mdBold(): String
{
    return this.md(BOLD)
}

/**
 * Underline this string using markdown
 *
 * @since 1.2.0
 * @return This string as underlined with markdown
 */
fun String.mdUnderline(): String
{
    return this.md(UNDERLINE)
}

/**
 * Strike this string using markdown
 *
 * @since 1.2.0
 * @return This string as stroke with markdown
 */
fun String.mdStrike(): String
{
    return this.md(STRIKE)
}

/**
 * Transform this string as markdown code
 *
 * @param lang The language of the code (optional)
 *
 * @since 1.2.0
 * @return This string as code in the given language with markdown
 */
fun String.mdCode(lang: String = ""): String
{
    return this.md(CODE, lang)
}

/**
 * Escape the markdown of this string with \
 *
 * @since 1.2.0
 * @return This string with markdown characters escaped
 */
fun String.mdEscape(): String
{
    var str = this

    if (mdTable() != null)
    {
        mdTable()!!.forEach { key, value ->
            str = str.replace(value, "\\$value")
        }
    }

    return str
}

/**
 * Delete the arguments of this String
 * Example : 'Hey {ARG} ho' become 'Hey  ho'
 *
 * @since 1.2.0
 * @return This string with no arguments
 */
private fun String.deleteArgs(): String
{
    return this.replace(ARGS_REGEX, "")
}

/**
 * Apply a markdown modifier
 *
 * @param key The key of the markdown modifier to apply
 * @param args The arguments to provide (example: one for the code modifier)
 *
 * @since 1.2.0
 * @return This string with the given markdown modified code applied
 */
fun String.md(key: String, vararg args: String): String
{
    var char = mdChar(key)
    var argIndex = 0

    char = char.replace(ARGS_REGEX, {
        if (args.size > argIndex)
        {
            args[argIndex]
        }
        else
        {
            ""
        }
    })

    return "$char$this$char"
}

/**
 * Convert a classic Markdown string to the specific current motor Markdown
 *
 * @since 1.2.0
 * @return This string, with converted Markdown
 */
fun String.mdConvert(): String
{
    val codes = arrayOf(EMPHASIS, BOLD, UNDERLINE, STRIKE, CODE)
    var result = this

    codes.forEach {
        result = result.replace(classicMarkdown[it]!!, mdChar(it))
    }

    return result
}

/**
 * Return the character of the given code from the current table
 * Example : In the default key table, mdChar(BOLD) returns '**'
 *
 * @see [mdTable]
 * @since 1.2.0
 * @return The character of the given code
 */
fun mdChar(key: String): String
{
    if (mdTable() == null)
    {
        return ""
    }

    return mdTable()!![key] ?: classicMarkdown[key] ?: ""
}

/**
 * Return the markdown character table (from the current motor or the default one)
 * A markdown tab assign the modifiers codes ([EMPHASIS], [BOLD], etc...) to a
 * character.
 *
 * Example : If table[BOLD] returns '**' it means that **word** should be a bold word
 *
 * @return The current markdown table
 */
fun mdTable(): HashMap<String, String>?
{
    if (classicMarkdown.size == 0)
    {
        classicMarkdown[EMPHASIS] = "_"
        classicMarkdown[BOLD] = "**"
        classicMarkdown[CODE] = "```\${LANG}"
        classicMarkdown[UNDERLINE] = "__"
        classicMarkdown[STRIKE] = "~~"
    }

    if (isBotStarted() && motor().markdownTable() != null)
    {
        return motor().markdownTable() ?: classicMarkdown
    }
    else
    {
        return classicMarkdown
    }
}