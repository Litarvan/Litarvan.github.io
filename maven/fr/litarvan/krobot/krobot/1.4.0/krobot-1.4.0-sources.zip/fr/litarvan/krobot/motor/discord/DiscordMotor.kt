/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.motor.discord

import fr.litarvan.krobot.bot.Bot
import fr.litarvan.krobot.motor.IMotor
import fr.litarvan.krobot.motor.IMotorExtension
import fr.litarvan.krobot.motor.User
import fr.litarvan.krobot.util.krobot
import fr.litarvan.krobot.util.logger
import net.dv8tion.jda.core.AccountType
import net.dv8tion.jda.core.JDA
import net.dv8tion.jda.core.JDABuilder
import net.dv8tion.jda.core.entities.ChannelType
import net.dv8tion.jda.core.events.ReadyEvent
import net.dv8tion.jda.core.events.ShutdownEvent
import net.dv8tion.jda.core.events.message.MessageReceivedEvent
import net.dv8tion.jda.core.events.message.priv.PrivateMessageReceivedEvent
import net.dv8tion.jda.core.hooks.ListenerAdapter
import java.io.File
import java.util.*

/**
 * The Discord Motor
 *
 *
 * The Discord Motor, provide full Discord support to Krobot
 * using the JDA <3 API
 *
 * @see JDA
 *
 * @author Litarvan
 * @version 1.4.0
 * @since 1.0.0
 */
class DiscordMotor : ListenerAdapter(), IMotor
{
    override val name = "Discord"
    override val identifier = "discord"
    override val version = "1.4.0"
    override var current : Bot? = null

    /**
     * The current [JDA] instance
     */
    private var jda : JDA? = null

    /**
     * The folder where the bots tokens are saved
     */
    val tokensFolder = File(krobot().folder, "discord-tokens")

    override fun init()
    {
        super.init()

        krobot().commandHandler.register(DiscordDeleteTokensCommand(this))
        tokensFolder.mkdirs()
    }

    override fun startBot(bot: Bot)
    {
        current = bot
        val sc = Scanner(System.`in`)

        if (jda != null)
        {
            logger().info("Session already created, shutting down the previous one")
            jda!!.shutdown()
        }

        val tokenFile = File(tokensFolder, bot.identifier)

        try
        {
            val savedToken = tokenFile.readText()

            logger().info("Trying to use the saved token...")
            connect(savedToken, bot)
        }
        catch (e: Exception)
        {
            logger().info("Can't use the saved token ! ${e.javaClass.simpleName} : ${e.message}")
            logger().info("[Discord Motor] Discord bot token : ")
            val token = sc.nextLine()

            tokenFile.writeText(token)
            connect(token, bot)
        }
    }

    private fun connect(token: String, bot: Bot)
    {
        logger().info("[Discord Motor] Connecting...")
        jda = JDABuilder(AccountType.BOT).setToken(token).addListener(this).buildBlocking()

        logger().info("[Discord Motor] Connected !")

        logger().info("Discord bot connected successfully")
        logger().info("Typing 'quit', 'exit' or 'stop' will now shutdown the bot instead of leaving Krobot")

        bot.extensions.indices.forEach {
            if (bot.extensions[it] is DiscordExtension)
                jda!!.addEventListener(bot.extensions[it] as DiscordExtension)
        }
    }

    override fun shutdownCurrent()
    {
        logger().info("Shutting down JDA")
        jda!!.shutdown()

        logger().info("Discord connection shut down")
        current!!.onStop(DiscordStopEvent(this))

        current = null

        logger().info("Discord motor, and bot shut down")
    }

    override fun onReady(event: ReadyEvent?)
    {
        super.onReady(event)

        current!!.onStart(DiscordStartEvent(this, event!!))
    }

    override fun onShutdown(event: ShutdownEvent?)
    {
        super.onShutdown(event)
    }

    override fun onMessageReceived(event: MessageReceivedEvent?)
    {
        super.onMessageReceived(event)

        if (event!!.author.id == jda!!.selfUser.id || event.isFromType(ChannelType.PRIVATE))
            return

        current!!.receiveMessage(DiscordMessage(event.message), DiscordUser(event.author), DiscordConversation(event.channel), false)
    }

    override fun onPrivateMessageReceived(event: PrivateMessageReceivedEvent?)
    {
        super.onPrivateMessageReceived(event)

        if (event!!.author.id == jda!!.selfUser.id)
            return

        current!!.receiveMessage(DiscordMessage(event.message), DiscordUser(event.author), DiscordConversation(event.channel), true)
    }

    override fun mention(user: User): String
    {
        return (user as DiscordUser).user.asMention
    }
}

/**
 * The Discord Motor Extension
 *
 *
 * This extension contains a JDA event listener [ListenerAdapter]
 * and is registered to the JDA instance.
 *
 * @see ListenerAdapter
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.0.0
 */
open class DiscordExtension : ListenerAdapter(), IMotorExtension
