/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.motor.skype

import com.skype.Chat
import com.skype.ChatMessage
import fr.litarvan.krobot.Krobot
import fr.litarvan.krobot.motor.Conversation
import fr.litarvan.krobot.motor.Message
import fr.litarvan.krobot.motor.User
import fr.litarvan.krobot.util.logger
import java.io.File

/**
 * The Skype User
 *
 *
 * This object represents a Skype User, it contains
 * a Skype User object
 *
 * @param user The Skype User
 *
 * @author Litarvan
 * @version 1.4.0
 * @since 1.0.0
 */
class SkypeUser(val user: com.skype.User) : User()
{
    override val id = user.id!!
    override val username: String = user.fullName
    override val privateConversation = SkypeConversation(user.chat())
}

/**
 * The Skype Message
 *
 *
 * This object represents a Skype Message, it contains
 * a Skype Message object
 *
 * @param message The Skype message
 *
 * @author Litarvan
 * @version 1.3.0
 * @since 1.0.0
 */
class SkypeMessage(val message: ChatMessage) : Message()
{
    override val id = message.id!!
    override val text: String = message.content
    override val author: User = SkypeUser(message.sender)
}

/**
 * The Skype Conversation
 *
 *
 * This object represents a Skype Conversation, it contains
 * a Skype [Chat] object
 *
 * @param chat The Skype [Chat]
 *
 * @see Chat
 *
 * @author Litarvan
 * @version 1.3.6
 * @since 1.0.0
 */
class SkypeConversation(val chat: Chat) : Conversation()
{
    override val id = chat.id!!
    override val private = chat.allActiveMembers.size == 1
    override val name = chat.windowTitle!!

    override fun sendMessage(content: String)
    {
        chat.send(content)
    }

    override fun sendFile(file: File)
    {
        logger().error("Send file called but not supported by the Skype API")
    }

    override fun userById(id: String): User?
    {
        chat.allMembers.forEach {
            if (it.id.trim().equals(id.trim()))
            {
                return SkypeUser(it)
            }
        }

        return null
    }

    override fun userByName(name: String): User?
    {
        chat.allMembers.forEach {
            if (it.fullName.trim().equals(name.trim()))
            {
                return SkypeUser(it)
            }
        }

        return null
    }

    override fun members(): Array<User>
    {
        val members = kotlin.arrayOfNulls<User>(chat.allMembers.size)

        for (i in 0..members.size - 1)
        {
            members[i] = SkypeUser(chat.allMembers[i])
        }

        return members.requireNoNulls()
    }
}