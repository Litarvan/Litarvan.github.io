/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.motor.skype

import com.skype.*
import fr.litarvan.krobot.bot.StartEvent
import fr.litarvan.krobot.bot.StopEvent
import fr.litarvan.krobot.motor.IMotor
import java.util.*

/**
 * The Skype Start Event
 *
 *
 * A [StartEvent] but used by Skype
 *
 * @see [StartEvent]
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.0.0
 */
class SkypeStartEvent(motor: IMotor) : StartEvent(motor)

/**
 * The Skype Stop Event
 *
 *
 * A [StopEvent] but used by Skype
 *
 * @see [StopEvent]
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.0.0
 */
class SkypeStopEvent(motor: IMotor) : StopEvent(motor)

/**
 * The Skype Event Listener
 *
 *
 * This Event Listener is a listener that contains
 * all the other skype listeners.
 *
 * @see [StopEvent]
 * @see [ChatListener]
 * @see [ChatMessageEditListener]
 * @see [ChatMessageListener]
 * @see [EventMessageListener]
 * @see [GlobalChatListener]
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.0.0
 */
interface SkypeEventListener : CallListener, ChatListener, ChatMessageEditListener, ChatMessageListener, EventMessageListener, GlobalChatListener

/**
 * The Skype Event Adapter
 *
 *
 * A [SkypeEventListener] but as abstract class so with optional
 * methods.
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.0.0
 */
abstract class SkypeEventAdapter : SkypeEventListener
{
    override fun callReceived(receivedCall: Call?)
    {
    }

    override fun callMaked(makedCall: Call?)
    {
    }

    override fun userLeft(user: User?)
    {
    }

    override fun userAdded(user: User?)
    {
    }

    override fun userLeft(chat: Chat?, user: User?)
    {
    }

    override fun userAdded(chat: Chat?, user: User?)
    {
    }

    override fun newChatStarted(chat: Chat?, users: Array<out User>?)
    {
    }

    override fun chatMessageEdited(editedMessage: ChatMessage?, eventDate: Date?, who: User?)
    {
    }

    override fun chatMessageReceived(receivedChatMessage: ChatMessage?)
    {
    }

    override fun chatMessageSent(sentChatMessage: ChatMessage?)
    {
    }

    override fun eventMessageClicked()
    {
    }
}