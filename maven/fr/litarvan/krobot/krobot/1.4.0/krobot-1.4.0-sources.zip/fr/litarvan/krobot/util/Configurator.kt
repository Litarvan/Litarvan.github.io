/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.util

import fr.litarvan.krobot.bot.Bot
import fr.litarvan.krobot.message.IMessageListener
import fr.litarvan.krobot.message.MessageReceivedEvent
import fr.litarvan.krobot.motor.Conversation
import java.util.*

/**
 * The Configurator
 *
 *
 * This class can do a message configuration of your bot.
 * To use it you need to provide a map, by example :
 *
 * ["name" => "Enter your name", "age", "Enter your age"]
 *
 * The questions will be asked one by one, then when finished
 * a lambda will be executed so you can get the values
 * using the [values] method, it will return an [HashMap]
 * with as keys the same keys that you provided and as
 * value the user responses.
 *
 * To use it, first run the init method and then register
 * him as [IMessageListener], a secret token will be printed
 * to the console, enter it to start the configuration as the
 * bot owner.
 *
 * @see HashMap
 * @see IMessageListener
 *
 * @author Litarvan
 * @version 1.3.5
 * @since 1.1.0
 */
class Configurator : IMessageListener
{
    /**
     * The current bot that is using this configurator
     */
    val bot: Bot

    /**
     * The questions to ask with their keys
     */
    val toAsk: Map<String, String>

    /**
     * If the configuration was done
     */
    var configured: Boolean = false
        private set

    /**
     * The secret token to use to "authenticate" the owner
     */
    private var token = UUID.randomUUID().toString()

    /**
     * The last asked question
     */
    private var lastQuestion: String? = null

    /**
     * The index of the asking question
     */
    private var questionIndex = 0

    /**
     * The values ([toAsk] keys => user responses)
     */
    private val values = HashMap<String, String>()

    /**
     * The bot owner (the one who entered the token)
     */
    private var owner: String? = null

    /**
     * The message to print when the configuration is done
     */
    private val doneMessage: String

    /**
     * A lambda to execute when the configuration is done
     */
    private var onFinish: ((Configurator, MessageReceivedEvent) -> Unit)? = null

    /**
     * @param bot The current bot that is using this configurator
     * @param toAsk The questions to ask with their keys
     * Example : ["name" => "Enter your name", "age", "Enter your age"]
     */
    constructor(bot: Bot, toAsk: Map<String, String>): this(bot, toAsk, "Done ! Bot configured !")

    /**
     * @param bot The current bot that is using this configurator
     * @param toAsk The questions to ask with their keys
     * Example : ["name" => "Enter your name", "age", "Enter your age"]
     * @param doneMessage The message to print when the configuration is done
     */
    constructor(bot: Bot, toAsk: Map<String, String>, doneMessage: String)
    {
        this.bot = bot
        this.toAsk = toAsk
        this.doneMessage = doneMessage

        bot.addMessageListener(this)
    }

    /**
     * Initialize the configurator (print to token to the console)
     */
    fun init()
    {
        logger().info("${prefix()} This bot is being launched for the first time")
        logger().info("${prefix()} To start configuration, send a message (private or not) with this token : $token")
    }

    override fun onMessageReceived(event: MessageReceivedEvent)
    {
        onPrivateMessageReceived(event)
    }

    override fun onPrivateMessageReceived(event: MessageReceivedEvent)
    {
        super.onPrivateMessageReceived(event)

        if (!configured)
        {
            event.cancelled = true
        }
        else
        {
            return
        }

        if (event.message.text.contains(token) && owner == null)
        {
            owner = event.user.username

            event.conversation.sendMessage("Starting bot configuration, $owner is the owner of the bot")
            next(event.conversation)
        }
        else if (owner != null && event.user.username.equals(owner))
        {
            values[lastQuestion!!] = event.message.text.trim()

            if (questionIndex < toAsk.size)
            {
                next(event.conversation)
            }
            else
            {
                configured = true
                event.conversation.sendMessage(toAsk["done"] ?: "Configured !")

                if (onFinish != null)
                {
                    onFinish!!(this, event)
                }
            }
        }
    }

    /**
     * Define a lambda that will be executed on the configuration end
     *
     * @param action The lambda
     */
    fun onFinish(action: (Configurator, MessageReceivedEvent) -> Unit)
    {
        onFinish = action
    }

    /**
     * Print the next configuration question on the given configuraiton
     *
     * @param conversation The conversation where to print the next question
     */
    private fun next(conversation: Conversation)
    {
        val question = toAsk.keys.elementAt(questionIndex)

        conversation.sendMessage(toAsk[question]!!)
        lastQuestion = question
        questionIndex++
    }

    /**
     * The final values, the keys are the one provided on the
     * constructor ([toAsk]) and the values are the user responses
     * to these questions.
     */
    fun values(): HashMap<String, String>
    {
        return values.clone() as HashMap<String, String>
    }
}