/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.motor.skype

import com.skype.ChatMessage
import com.skype.ChatMessageListener
import com.skype.Skype
import fr.litarvan.krobot.bot.Bot
import fr.litarvan.krobot.motor.IMotor
import fr.litarvan.krobot.motor.IMotorExtension
import fr.litarvan.krobot.util.*
import java.util.*

/**
 * The Skype Motor
 *
 *
 * The Skype Motor, provide full Skype support to Krobot
 * using the Skype API
 *
 * @see Skype
 *
 * @author Litarvan
 * @version 1.4.0
 * @since 1.0.0
 */
class SkypeMotor : ChatMessageListener, IMotor
{
    override val name: String = "Skype"
    override val identifier: String = "skype"
    override val version: String = "1.4.0"

    override var current : Bot? = null

    override fun startBot(bot: Bot)
    {
        logger().info("Skype API version ${Skype.LIBRARY_VERSION}")
        if (!Skype.isRunning())
        {
            logger().info("Skype is not running, please launch it to use the Skype Motor")
            return
        }

        Skype.addChatMessageListener(this)
        bot.extensions.indices.forEach {
            if (bot.extensions[it] is SkypeExtension)
            {
                val ext = bot.extensions[it] as SkypeExtension

                Skype.addCallListener(ext)
                Skype.addChatMessageEditListener(ext)
                Skype.addGlobalChatListener(ext)
                Skype.addChatMessageListener(ext)
            }
        }

        logger().info("Skype running, bot initialized.")

        current = bot
    }

    override fun chatMessageReceived(receivedChatMessage: ChatMessage?)
    {
        current!!.receiveMessage(SkypeMessage(receivedChatMessage!!), SkypeUser(receivedChatMessage.sender), SkypeConversation(receivedChatMessage.chat), receivedChatMessage.chat.allMembers.size == 2)
    }

    override fun chatMessageSent(sentChatMessage: ChatMessage?)
    {
    }

    override fun shutdownCurrent()
    {
        Skype.removeChatMessageListener(this)
        current!!.extensions.indices.forEach {
            if (current!!.extensions[it] is SkypeExtension)
            {
                val ext = current!!.extensions[it] as SkypeExtension

                Skype.removeCallListener(ext)
                Skype.removeChatMessageEditListener(ext)
                Skype.removeGlobalChatListener(ext)
                Skype.removeChatMessageListener(ext)
            }
        }

        current!!.onStop(SkypeStopEvent(this))

        logger().info("Skype motor, and bot shut down")
    }

    override fun markdownTable(): HashMap<String, String>
    {
        val table = HashMap<String, String>()

        table[EMPHASIS] = "_"
        table[BOLD] = "*"
        table[STRIKE] = "~"
        table[CODE] = "{code}"

        return table
    }
}

/**
 * The Skype Motor Extension
 *
 *
 * This extension contains a Skype event listener [SkypeEventAdapter]
 * and is registered to the Skype instance.
 *
 * @see SkypeEventAdapter
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.0.0
 */
class SkypeExtension : SkypeEventAdapter(), IMotorExtension