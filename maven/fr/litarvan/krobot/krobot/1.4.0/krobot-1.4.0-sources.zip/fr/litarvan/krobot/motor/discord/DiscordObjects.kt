/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.motor.discord

import fr.litarvan.krobot.motor.Conversation
import fr.litarvan.krobot.motor.Message
import fr.litarvan.krobot.motor.User
import net.dv8tion.jda.core.entities.MessageChannel
import net.dv8tion.jda.core.entities.PrivateChannel
import net.dv8tion.jda.core.entities.TextChannel
import java.io.File

/**
 * The Discord User
 *
 *
 * This object represents a Discord User, it contains
 * a JDA User object
 *
 * @param user The JDA User
 *
 * @author Litarvan
 * @version 1.4.0
 * @since 1.0.0
 */
class DiscordUser(val user : net.dv8tion.jda.core.entities.User) : User()
{
    override val username = user.name!!
    override val id = user.id!!
    override val privateConversation = DiscordConversation(user.privateChannel)

    /**
     * The URL of the user avatar (can be empty if user has default avatar)
     */
    val avatar = user.avatarUrl ?: ""
}

/**
 * The Discord Message
 *
 *
 * This object represents a Discord Message, it contains
 * a JDA Message object
 *
 * @param message The JDA message
 *
 * @author Litarvan
 * @version 1.3.0
 * @since 1.0.0
 */
class DiscordMessage(val message: net.dv8tion.jda.core.entities.Message) : Message()
{
    override val id = message.id!!
    override val text = message.content!!
    override val author = DiscordUser(message.author)
}

/**
 * The Discord Conversation
 *
 *
 * This object represents a Discord Conversation, it contains
 * a JDA Channel object
 *
 * @param channel The JDA [MessageChannel]
 *
 * @see MessageChannel
 *
 * @author Litarvan
 * @version 1.3.6
 * @since 1.0.0
 */
class DiscordConversation(val channel: MessageChannel) : Conversation()
{
    override val name = if (channel is PrivateChannel)
    {
        channel.user.name!!
    }
    else if (channel is TextChannel)
    {
        channel.name!!
    }
    else
    {
        "Unknown Channel"
    }

    override val id = channel.id!!
    override val private = channel is PrivateChannel

    override fun sendMessage(content: String)
    {
        channel.sendMessage(content)
    }

    override fun sendFile(file: File)
    {
        channel.sendFile(file, null)
    }

    override fun members(): Array<User>
    {
        if (channel is PrivateChannel)
        {
            return arrayOf(DiscordUser(channel.user))
        }

        val members = kotlin.arrayOfNulls<User>((channel as TextChannel).members.size)

        for (i in 0..members.size - 1)
        {
            members[i] = DiscordUser(channel.members[i].user)
        }

        return members.requireNoNulls()
    }

    override fun userById(id: String): User?
    {
        members().forEach {
            if (it.id.trim().equals(id.trim()))
            {
                return it
            }
        }

        return null
    }

    override fun userByName(name: String): User?
    {
        members().forEach {
            if (it.username.equals(name.trim()))
            {
                return it
            }
        }

        return null
    }
}