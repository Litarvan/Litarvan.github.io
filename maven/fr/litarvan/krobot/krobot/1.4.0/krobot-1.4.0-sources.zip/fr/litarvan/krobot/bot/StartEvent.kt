package fr.litarvan.krobot.bot

import fr.litarvan.krobot.motor.IMotor

/**
 * The Start Event
 *
 *
 * This message is used by the [Bot] and called by the
 * [IMotor] when starting a [Bot]
 *
 * @param motor The used motor
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.0.0
 */
open class StartEvent(motor: IMotor)