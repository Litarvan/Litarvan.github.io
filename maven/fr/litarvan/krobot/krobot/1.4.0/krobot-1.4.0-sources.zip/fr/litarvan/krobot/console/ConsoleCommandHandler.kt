/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.console

import java.io.BufferedReader
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader

import fr.litarvan.krobot.Krobot
import fr.litarvan.krobot.command.Command
import fr.litarvan.krobot.command.CommandHandler
import fr.litarvan.krobot.command.ICommandCaller
import fr.litarvan.krobot.console.command.*
import fr.litarvan.krobot.exception.CommandException
import fr.litarvan.krobot.util.krobot
import fr.litarvan.krobot.util.logger

/**
 * The Console Command Handler
 *
 *
 * Handle the command called in the Krobot interactive console.
 * You can use it to register some commands for the admin to
 * interact with your bot.
 *
 * @author Litarvan
 * @version 1.3.0
 * @since 1.0.0
 */
class ConsoleCommandHandler : CommandHandler()
{
    override fun handleBadSyntax(caller: ICommandCaller, command: Command, args: List<String>)
    {
        System.err.println("Syntax: " + command.command + " " + command.syntax)
    }

    override fun handleUnknownCommand(caller: ICommandCaller, command: String, args: List<String>)
    {
        System.err.println("Unknown command ! Type 'help' for a list of command")
    }

    /**
     * The reader that read the console input stream
     */
    val reader = BufferedReader(InputStreamReader(System.`in`))

    init
    {
        // Registering the pre-defined commands
        register(HelpCommand())
        register(VersionCommand())
        register(LaunchCommand())
        register(BotsCommand())
        register(MotorsCommand())
    }

    /**
     * Listen for commands, and handle them
     *
     * @throws IOException      If the reader threw one
     * @throws CommandException If the command threw one
     */
    @Throws(IOException::class, CommandException::class)
    fun listen()
    {
        var line: String?

        logger().info("Listening for commands...")

        mainLoop@ while (true)
        {
            print("> ")
            line = reader.readLine()

            if (line != null)
            {
                line = line.trim { it <= ' ' }
            }

            if (line == null || line == "stop" || line == "exit" || line == "quit")
            {
                println()

                krobot().shutdown()
            }
            else
            {
                handle(line, ConsoleCommandCaller())
            }
        }
    }
}
