/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.command

/**
 * The Command
 *
 *
 * The Command is something like this : /command arg1 arg2
 * Create a Command class and then register it to your
 * [CommandHandler] to use it. The one who call the command is
 * the [ICommandCaller].
 *
 * @see CommandHandler
 * @see ICommandCaller
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.0.0
 */
abstract class Command
{
    /**
     * The command string (/THIS arg1 arg1)
     */
    abstract val command: String

    /**
     * The command description (what it does, in few words)
     */
    abstract val description: String

    /**
     * The command syntax as a string (ex: <required arg> [optional args...])
     *
     * @see checkSyntax
     */
    abstract val syntax: String

    /**
     * The required permission to launch this command (default is empty)
     */
    open val requiredPermission = ""

    /**
     * Check the command syntax by the given arguments
     *
     * @param args The arguments to check
     *
     * @return True if the syntax is correct, false if not
     */
    abstract fun checkSyntax(args: List<String>): Boolean

    /**
     * Called when the command is called with a valid syntax
     * (after being checked by the [checkSyntax] method)
     *
     * @param args The given arguments
     *
     * @see checkSyntax
     */
    abstract fun handleCall(caller: ICommandCaller, args: List<String>)
}
