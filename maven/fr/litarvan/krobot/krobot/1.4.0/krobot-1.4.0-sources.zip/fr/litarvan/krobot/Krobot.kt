/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot

import fr.litarvan.krobot.bot.Bot
import fr.litarvan.krobot.console.ConsoleCommandHandler
import fr.litarvan.krobot.motor.IMotor
import fr.litarvan.krobot.exception.CommandException
import fr.litarvan.krobot.exception.CrashReporter
import fr.litarvan.krobot.motor.discord.DiscordMotor
import fr.litarvan.krobot.motor.skype.SkypeMotor
import fr.litarvan.krobot.plugin.BotLoader
import fr.litarvan.krobot.plugin.MotorLoader
import fr.litarvan.krobot.util.krobot
import fr.litarvan.krobot.util.logger
import fr.litarvan.krobot.util.reporter
import joptsimple.OptionParser
import joptsimple.OptionSet
import org.apache.logging.log4j.Level
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.core.LoggerContext
import java.io.File
import java.io.IOException

/**
 * The Krobot object
 *
 * The Krobot object handle the start, manage the launch arguments,
 * all the main things like the MotorLoader or the BotLoader,
 * and start the interactive console.
 *
 * @param isDebugEnabled If debug is enabled
 * @param folder The Krobot folder
 * @param crashesFolder The folder where the [CrashReporter] crashes are
 * @param motorFolder The folder where are the [IMotor]s
 * @param botFolder The folder where are the [Bot]s
 *
 * @author Litarvan
 * @version 1.4.0
 * @since 1.0.0
 */
class Krobot(val isDebugEnabled: Boolean, val folder: File, val crashesFolder: File, val motorFolder: File, val botFolder: File)
{
    /**
     * The console command handler who manage the commands
     * of the interactive console
     */
    val commandHandler = ConsoleCommandHandler()

    /**
     * The motor loader, the one who manage all the motors and load
     * them from the motor folder
     */
    val motorLoader = MotorLoader(motorFolder)

    /**
     * The bot loader, the one who manage all the bots and load
     * them from the bot folder
     */
    val botLoader = BotLoader(botFolder)

    /**
     * The current started motor used with the started bot
     */
    var startedMotor: IMotor? = null
        internal set

    /**
     * The current crash reporter
     */
    val crashReporter = CrashReporter(crashesFolder)

    init
    {
        instance = this
    }

    /**
     * Start krobot and its interactive console
     */
    fun start()
    {
        return start(null, null)
    }

    /**
     * Start krobot with predefined bot using predefined motor
     *
     * @param motor The motor to use for the given bot (optional, required if bot was given)
     * @param bot The bot to start (optional, required if motor was given)
     */
    fun start(motor: String?, bot: String?)
    {
        LOGGER.info("Krobot version " + VERSION)

        if (motor == null && bot != null)
        {
            error("If you provide a bot you need to also provide a motor")
        }
        else if (motor != null && bot == null)
        {
            error("If you provide a motor you need to also provide a bot")
        }

        if (isDebugEnabled)
        {
            val ctx = LogManager.getContext(false) as LoggerContext
            val config = ctx.configuration
            val loggerConfig = config.getLoggerConfig("Krobot")

            loggerConfig.level = Level.DEBUG
            ctx.updateLoggers()
        }

        motorLoader.start()

        motorLoader.load(SkypeMotor())
        motorLoader.load(DiscordMotor())

        botLoader.start()


        if (motor != null && bot != null)
        {
            launch(motor, bot)
        }

        LOGGER.info("Type 'quit', 'stop', or 'exit' to exit")

        if (System.getProperty(DISABLE_CONSOLE_PROPERTY) == null || System.getProperty(DISABLE_CONSOLE_PROPERTY) != "true")
        {
            try
            {
                commandHandler.listen()
            }
            catch (e: IOException)
            {
                LOGGER.error("Exception while listening for command !", e)
            }
            catch (e: CommandException)
            {
                LOGGER.error("Exception while listening for command !", e)
            }
        }
    }

    /**
     * Shutdown Krobot
     */
    fun shutdown()
    {
        if (krobot().startedMotor != null)
        {
            logger().info("Shutting down the current motor")

            krobot().startedMotor!!.shutdownCurrent()
            krobot().startedMotor = null
        }
        else
        {
            logger().info("Bye !")
            System.exit(0)
        }
    }

    /**
     * Launch the given bot with the given motor
     *
     * @param motorName The motor to use to start the given bot
     * @param botName The bot to start
     */
    fun launch(motorName: String, botName: String)
    {
        var motor : IMotor? = null
        var bot : Bot? = null

        krobot().motorLoader.motors.forEach {
            if (it.identifier.equals(motorName))
            {
                motor = it
            }
        }

        krobot().botLoader.bots.forEach {
            if (it.identifier.equals(botName))
            {
                bot = it
            }
        }

        if (motor == null)
        {
            logger().info("Can't find the motor '$motorName'")
            return
        }

        if (bot == null)
        {
            logger().info("Can't find the bot '$botName'")
            return
        }

        logger().info("Starting bot ${bot!!.name} (v${bot!!.version}) using motor ${motor!!.name} (v${motor!!.version})")
        krobot().startedMotor = motor
        motor!!.startBot(bot as Bot)
    }

    companion object
    {
        /**
         * The Krobot version
         */
        const val VERSION = "1.4.0"

        /**
         * If this property is set to true there will not be an interactive console
         */
        const val DISABLE_CONSOLE_PROPERTY = "krobot.disable-console";

        /**
         * The Krobot logger
         */
        @JvmField val LOGGER = LogManager.getLogger("Krobot")!!

        /**
         * The Krobot folder
         */
        @JvmField val DEFAULT_FOLDER = System.getProperty("user.home") + "/Krobot/"

        /**
         * The main Krobot instance
         */
        lateinit var instance: Krobot
            private set

        /**
         * Parse the arguments, create Krobot, and start it

         * @param args The given arguments
         */
        @JvmStatic
        fun main(args: Array<String>)
        {
            val parser = OptionParser()

            parser.accepts("d")
            parser.accepts("f").withRequiredArg()
            parser.accepts("m").withRequiredArg()
            parser.accepts("b").withRequiredArg()
            parser.accepts("h")
            parser.accepts("v")

            parser.accepts("debug")
            parser.accepts("folder").withRequiredArg()
            parser.accepts("motor").withRequiredArg()
            parser.accepts("bot").withRequiredArg()
            parser.accepts("crashesFolder").withRequiredArg()
            parser.accepts("motorFolder").withRequiredArg()
            parser.accepts("botFolder").withRequiredArg()
            parser.accepts("help")
            parser.accepts("version")

            val set = parser.parse(*args)

            val help = set.has("h") || set.has("help")
            val version = set.has("v") || set.has("version")

            if (help)
                displayHelp()
            else if (version)
                displayVersion(true)

            val debug = set.has("d") || set.has("debug")

            val folder = getString(set, "f", "folder", DEFAULT_FOLDER)
            val crashesFolder = getString(set, null, "crashesFolder", folder + "/crashes")
            val motorFolder = getString(set, null, "motorFolder", folder + "/motors")
            val botFolder = getString(set, null, "botFolder", folder + "/bots")

            val motor = getString(set, "m", "motor", null)
            val bot = getString(set, "b", "bot", null)

            val krobot = Krobot(debug, File(folder), File(crashesFolder), File(motorFolder), File(botFolder))

            try
            {
                krobot.start(motor, bot)
            }
            catch (e: Exception)
            {
                reporter().catchError(e, "Start error")
            }

        }

        /**
         * Get an argument from an option set, and quit after displayed an error if the argument is
         * required (no default value) and no value was found
         *
         * @param set           The [OptionSet] where to get the argument
         * @param shortArgument The short version of the argument
         * @param longArgument  The long version of the argument
         * @param def           The default value of the argument
         *
         * @return The argument value
         */
        @JvmStatic
        private fun getString(set: OptionSet, shortArgument: String?, longArgument: String, def: String?): String?
        {
            var argument: String? = null

            if (set.has(shortArgument) && shortArgument != null)
            {
                argument = getStringArgument(set, shortArgument)
            }
            else if (set.has(longArgument))
            {
                argument = getStringArgument(set, longArgument)
            }

            return argument ?: return def
        }

        /**
         * Return an argument value from an OptionSet
         *
         * @param set      The [OptionSet] where to get the argument
         * @param argument The argument key
         *
         * @return The argument value
         */
        @JvmStatic
        private fun getStringArgument(set: OptionSet, argument: String): String
        {
            val value = set.valueOf(argument)

            if (value !is String)
            {
                error("Can't parse " + (if (argument.length == 1) "-" else "--") + argument + " argument")
            }

            return value as String
        }

        /**
         * Display an error message, a suggestion for the help command,
         * and then quit.
         *
         * @param message The error message
         */
        @JvmStatic
        private fun error(message: String)
        {
            println(message)
            println("Try `krobot --help' for more information.")

            System.exit(1)
        }

        /**
         * Display the help message
         */
        @JvmStatic
        private fun displayHelp()
        {
            println("Usage: krobot [OPTION]...\n\nLaunch krobot in an interactive shell, or with the given motor and bot if provided.\n\n  -m, --motor MOTOR            The name of the motor to use (required if --bot is provided)\n  -b, --bot BOT                The name of the bot to use (required if --motor is provided)\n  -d, --debug                  Enable the debug messages\n  -f, --folder FOLDER          Set the krobot folder (default is ~/Krobot/)\n  --crashesFolder FOLDER       The folder where the crashes logs will be\n  --motorsFolder FOLDER        The folder where the motors .jar are located\n  --botsFolder FOLDER          The folder where the bots .jar are located\n  -h, --help                   Display this help and exit\n  -v, --version                Output version information and exit")
            System.exit(0)
        }

        /**
         * Display the version message
         *
         * @param exit If set to true, will quite after displayed the message
         */
        fun displayVersion(exit: Boolean)
        {
            println("\nKrobot version $VERSION\nby Litarvan\n\nCopyright 2015-2016 Adrien 'Litarvan' Navratil\n\nKrobot is distributed in the hope that it will be useful,\nbut WITHOUT ANY WARRANTY; without even the implied warranty of\nMERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\nGNU Lesser General Public License for more details.\n\nYou should have received a copy of the GNU Lesser General Public License\nalong with Krobot.  If not, see <http://www.gnu.org/licenses/>.\n")

            if (exit)
            {
                System.exit(0)
            }
        }
    }
}
