/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.util

import org.apache.commons.lang3.StringUtils
import java.util.*

/**
 * The Response Analyser
 *
 *
 * The response analyser can provide, from a string list,
 * the most similar string from a given one.
 *
 * Example : You give "Helo", and as list : ["Hi", "Hello", "Good Morning"]
 * The [get] method will return 1 (because Helo is very similar to "Hello", the
 * second object of the list)
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.0.0
 */
class ResponseAnalyser(val response: String, val responses: Array<String>)
{
    /**
     * The LevenshteinDistance between the given string and the given list
     */
    private val matches = ArrayList<Int>()

    /**
     * @return The index of the most similar string of the list
     */
    fun get(): Int
    {
        responses.forEach {
            matches.add(StringUtils.getLevenshteinDistance(response, it))
        }

        return biggest()
    }

    /**
     * @return The index of the string with the biggest Levenshtein distance
     */
    fun biggest(): Int
    {
        var candidateIndex = 0
        var candidate = Int.MAX_VALUE

        for (i in matches.indices)
        {
            if (matches[i] < candidate)
            {
                candidate = matches[i]
                candidateIndex = i
            }
        }

        if (candidate > 10)
        {
            return -1
        }

        return candidateIndex
    }
}