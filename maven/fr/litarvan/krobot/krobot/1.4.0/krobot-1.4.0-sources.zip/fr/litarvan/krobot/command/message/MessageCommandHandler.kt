/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.command.message

import fr.litarvan.krobot.message.IMessageListener
import fr.litarvan.krobot.message.MessageReceivedEvent
import fr.litarvan.krobot.command.Command
import fr.litarvan.krobot.command.CommandHandler
import fr.litarvan.krobot.command.ICommandCaller
import fr.litarvan.krobot.util.mention

/**
 * The Message Command Handler
 *
 *
 * This [CommandHandler] can parse commands using a given prefix
 * (can be empty) from conversation messages. To use it you need
 * to register him as a [IMessageListener]. When a command is
 * called, the caller is a [MessageCommandCaller].
 *
 * It cancels the message message when receiving a command.
 *
 * @param prefix The command prefix to use. Example : /test arg1, / is the prefix
 *
 * @see CommandHandler
 * @see IMessageListener
 * @see MessageCommandCaller
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.1.0
 */
class MessageCommandHandler(val prefix: String) : CommandHandler(), IMessageListener
{
    override fun onPrivateMessageReceived(event: MessageReceivedEvent)
    {
        super.onPrivateMessageReceived(event)
        onMessageReceived(event)
    }

    override fun onMessageReceived(event: MessageReceivedEvent)
    {
        if (event.message.text.startsWith(prefix))
        {
            handle(event.message.text.substring(prefix.length), MessageCommandCaller(event.user, event.conversation))
            event.cancelled = true
        }
    }

    override fun handleBadSyntax(caller: ICommandCaller, command: Command, args: List<String>)
    {
        (caller as MessageCommandCaller).conversation.sendMessage("${mention(caller.user)} Syntax : ${command.command} ${command.syntax}")
    }

    override fun handleUnknownCommand(caller: ICommandCaller, command: String, args: List<String>)
    {
        (caller as MessageCommandCaller).conversation.sendMessage("${mention(caller.user)} Unknown command '$command'")
    }
}