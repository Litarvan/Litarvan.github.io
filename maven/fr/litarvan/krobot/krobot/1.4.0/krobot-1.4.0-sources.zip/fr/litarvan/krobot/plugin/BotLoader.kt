/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.plugin

import fr.litarvan.krobot.bot.Bot
import fr.litarvan.krobot.util.logger
import java.io.File
import java.util.*

/**
 * The Bot Loader
 *
 *
 * The [Bot] Loader is an object that loads the [Bot]s .jar
 * from the given [Bot] folder
 *
 * @see Bot
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.0.0
 */
class BotLoader(folder: File) : PluginLoader<Bot>(folder)
{
    /**
     * All the loaded bots
     */
    val bots = ArrayList<Bot>()

    override fun load(plugin: Bot)
    {
        logger().info("Registering bot ${plugin.name} (version ${plugin.version})")

        bots.add(plugin)
        plugin.init()
    }
}