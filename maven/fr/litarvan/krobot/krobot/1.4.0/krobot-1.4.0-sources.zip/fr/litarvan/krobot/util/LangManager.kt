/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.util

import java.util.*

/**
 * The Lang Manager
 *
 *
 * The Lang Manager use [ResourceBundle] to manage translations.
 * To use it, you need to create .properties in your jar.
 *
 * Choose a "prefix", then create files like that :
 *
 * - package/prefix_en.properties
 * - package/prefix_fr.properties
 * - package/prefix_fr_ca.properties
 * - etc.
 *
 * Then, create a LangManager object with as path : 'package.prefix',
 * and use the [trans] method to translate a string.
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.2.0
 */
class LangManager(val path: String)
{
    /**
     * The list of the loaded bundles
     */
    private val map = HashMap<Locale, ResourceBundle>()

    /**
     * Get the translation with the given key from the given locale
     *
     * @param key The key of the translation to get
     * @param locale The locale to use
     *
     * @return The translated string
     */
    fun trans(key: String, locale: Locale = Locale.ENGLISH): String
    {
        return bundle(locale).getString(key)
    }

    /**
     * Get a resource bundle from the given locale
     *
     * @param locale The locale of the bundle to get
     *
     * @return The loaded bundle
     */
    fun bundle(locale: Locale = Locale.ENGLISH): ResourceBundle
    {
        if (map.containsKey(locale))
        {
            return map[locale]!!
        }

        val bundle = ResourceBundle.getBundle(path, locale)
        map[locale] = bundle

        return bundle
    }
}