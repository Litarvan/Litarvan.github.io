/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.bot

import fr.litarvan.krobot.message.IMessageListener
import fr.litarvan.krobot.message.MessageReceivedEvent
import fr.litarvan.krobot.motor.Conversation
import fr.litarvan.krobot.motor.IMotorExtension
import fr.litarvan.krobot.motor.Message
import fr.litarvan.krobot.motor.User
import fr.litarvan.krobot.motor.IMotor
import java.util.*

/**
 * The Bot
 *
 *
 * One of the main Krobot classes, a Bot is a program that
 * can interact with a chat like Discord or Skype.
 *
 * It can manage the [IMessageListener], and it is one also.
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.0.0
 */
abstract class Bot : IMessageListener
{
    /**
     * The bot registered [IMessageListener]s
     */
    private val messageListeners = ArrayList<IMessageListener>()

    /**
     * The bot name
     */
    abstract val name : String

    /**
     * The bot identifier (must not contains space or any special character,
     * and should be lower case)
     */
    abstract val identifier : String

    /**
     * The bot current version
     */
    abstract val version : String

    /**
     * The registered [IMotorExtension]s
     */
    abstract val extensions : Array<IMotorExtension>

    /**
     * The init method, called when Krobot load the bot
     */
    fun init() {}

    /**
     * Called when the bot is launched
     *
     * @param event The [StartEvent]
     */
    abstract fun onStart(event: StartEvent)

    /**
     * Called when the bot is being stopped
     *
     * @param event The [StopEvent]
     */
    open fun onStop(event: StopEvent) {}

    /**
     * Register a [IMessageListener]
     *
     * @param listener The listener to register
     */
    fun addMessageListener(listener: IMessageListener)
    {
        messageListeners.add(listener)
    }

    /**
     * Receive a message, used by the current [IMotor] to call
     * the listeners and create the event.
     */
    fun receiveMessage(message: Message, user: User, conversation: Conversation, private: Boolean)
    {
        val event = MessageReceivedEvent(message, conversation, user)
        val listeners = messageListeners.toTypedArray()

        listeners.forEach {
            it.onMessageReceived(event)
        }

        if (!event.cancelled)
        {
            if (private)
            {
                onPrivateMessageReceived(event)
            }
            else
            {
                onMessageReceived(event)
            }
        }
    }
}