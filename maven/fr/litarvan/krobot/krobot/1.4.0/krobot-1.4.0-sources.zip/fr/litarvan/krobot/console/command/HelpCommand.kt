/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.console.command

import fr.litarvan.krobot.command.Command
import fr.litarvan.krobot.command.ICommandCaller
import fr.litarvan.krobot.util.krobot

/**
 * The Help Command
 *
 *
 * This console command displays a list of all the commands
 * registered in the Krobot console command handler and
 * print them with their description and their syntax.
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.0.0
 */
class HelpCommand : Command()
{
    override val command: String = "help"
    override val description: String = "Display the list of command with their description and their syntax"
    override val syntax: String = ""

    override fun checkSyntax(args: List<String>): Boolean = args.size == 0

    override fun handleCall(caller: ICommandCaller, args: List<String>)
    {
        println("Registered commands :")

        krobot().commandHandler.commandList.forEach {
            println("    " + it.command + " " + it.syntax + "\n        " + it.description)
        }
    }
}
