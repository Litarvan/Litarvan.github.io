/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.motor.discord

import fr.litarvan.krobot.command.Command
import fr.litarvan.krobot.command.ICommandCaller

/**
 * The Discord Delete Tokens Command
 *
 *
 * This command delete all the tokens saved by the
 * Discord motor.
 *
 * @author Litarvan
 * @version 1.2.3
 * @since 1.2.3
 */
class DiscordDeleteTokensCommand(val motor: DiscordMotor) : Command()
{
    override val command = "discord-delete-tokens"
    override val description = "Delete the saved Discord bot tokens"
    override val syntax = ""

    override fun checkSyntax(args: List<String>): Boolean
    {
        return args.size == 0
    }

    override fun handleCall(caller: ICommandCaller, args: List<String>)
    {
        motor.tokensFolder.deleteRecursively()
    }
}