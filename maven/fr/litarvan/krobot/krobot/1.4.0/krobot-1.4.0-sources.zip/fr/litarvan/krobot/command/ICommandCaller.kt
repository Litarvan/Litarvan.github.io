/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.command

import fr.litarvan.krobot.command.message.*

/**
 * The Command Caller
 *
 *
 * A Command Caller is an object that represent what/who called
 * a [Command]. It is used by the [CommandHandler] to get some
 * information. Example, the [MessageCommandCaller] is used
 * when a command was called by a message using the
 * [MessageCommandHandler] and contains the user and the
 * conversation.
 *
 * @see Command
 * @see CommandHandler
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.1.0
 */
interface ICommandCaller

