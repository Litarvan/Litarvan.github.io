/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.command

/**
 * The Command Listener
 *
 *
 * The Command Listener is an message listener who wait for
 * a command to be called. It is called by the [CommandHandler]
 * and use the [CommandCalledEvent] to get information and
 * sometime cancel the message.
 *
 * @see CommandHandler
 * @see CommandCalledEvent
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.0.0
 */
interface ICommandListener
{
    /**
     * Handle a command before its real calling
     *
     * @param event The message
     */
    fun handleCommand(event: CommandCalledEvent)
}
