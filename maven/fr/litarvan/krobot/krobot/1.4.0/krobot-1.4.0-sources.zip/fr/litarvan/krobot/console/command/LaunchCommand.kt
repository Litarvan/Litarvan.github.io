/*
 * Copyright 2015-2016 Adrien 'Litarvan' Navratil
 *
 * This file is part of Krobot.

 * Krobot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Krobot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Krobot.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.litarvan.krobot.console.command

import fr.litarvan.krobot.command.Command
import fr.litarvan.krobot.command.ICommandCaller
import fr.litarvan.krobot.util.krobot

import fr.litarvan.krobot.bot.Bot
import fr.litarvan.krobot.motor.IMotor

/**
 * The Launch Command
 *
 *
 * This command launch the given [Bot] using the given [IMotor].
 *
 * @author Litarvan
 * @version 1.2.0
 * @since 1.0.0
 */
class LaunchCommand : Command()
{
    override val command: String = "launch"
    override val description: String = "Launch a bot with the given motor"
    override val syntax: String = "<motor> <bot>"

    override fun checkSyntax(args: List<String>): Boolean = args.size == 2

    override fun handleCall(caller: ICommandCaller, args: List<String>)
    {
        krobot().launch(args[0], args[1])
    }
}